package com.travels.pages;


import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.Select;

public class supplierbackend {
	WebDriver driver;
	
	@FindBy(xpath="//input[(@type='text')]")
	private WebElement email;
	
	@FindBy(xpath="//input[(@name='password')]")
	private WebElement password;
	
	@FindBy(xpath="//button[(@type='submit')]")
	private WebElement login;
	
	@FindBy(xpath="//button[(@id='dropdownMenuProfile')]")
	private WebElement dropdown;
	
	@FindBy(xpath="//a[(@href='https://phptravels.net/api/supplier/logout')]")
	private WebElement logout;
	
	@FindBy(xpath="//div[(text()='Sales overview & summary')]")
	private WebElement text;
	
	@FindBy(xpath="//canvas[(@id='dashboardBarChart')]")
	private WebElement image;
	
	@FindBy(xpath="//div[(text()='Pending Bookings')]")
	private WebElement pending;
	
	@FindBy(xpath="/html/body/div[2]/div[2]/main/div/div[2]/div/div/div[2]/table/tbody/tr[1]/td[11]/select/option[2]")
	private WebElement confirmed;
	
	@FindBy(xpath="/html/body/div[2]/div[2]/main/div/div[2]/div/div/div[2]/table/tbody/tr[1]/td[11]/select")
	private WebElement pendingdropdown;
	
	
	  @FindBy(xpath="/html/body/nav/div/div/ul/li[2]/a") 
	  private WebElement bookings;
	  
	  @FindBy(xpath="/html/body/div[2]/div[1]/nav/div/div/a[6]") 
	  private WebElement tours;
	  
	  @FindBy(xpath="/html/body/div[2]/div[1]/nav/div/div/div[9]/nav/a") 
	  private WebElement tours1;
	  
	  @FindBy(xpath="/html/body/div[2]/div[1]/nav/div/div/div[9]/nav/div[1]/nav/a[1]") 
	  private WebElement managetours;
	  
	  @FindBy(xpath="/html/body/div[2]/div[2]/main/div/div[2]/div/div/div[2]/div/table/tbody/tr/td")
		private WebElement nodata;
	 
	
	@FindBy(xpath="//a[1][(@href='https://phptravels.net/api/supplier')]")
	private WebElement board;
	
	@FindBy(xpath="/html/body/div[2]/div[2]/main/div/div[2]/div[1]/a/div/div/div/div[1]/div[1]")
	private WebElement numconfirm;
	
	@FindBy(xpath="/html/body/div[2]/div[2]/main/div/div[2]/div[2]/a/div/div/div/div[1]/div[1]")
	private WebElement numpending;
	
	public supplierbackend (WebDriver driver) {
		this.driver = driver;
		PageFactory.initElements(driver, this);
	}
	
	public void setEmail(String emailid) 
	  { 
		email.sendKeys(emailid); 
		  }
	
	public void setpassword(String pswd) 
	  { 
		password.sendKeys(pswd); 
		  }
	
	 public void clickLogin() 
	  { 
		 login.click();
		 }
	 
	 public void clickDropdown() 
	  { 
		 dropdown.click();
		 }
	 
	 public void clickLogout() 
	  { 
		 logout.click();
		 }
	 
	 public void selectText()
	 {
		 String text1="Sales overview & summary";
		 String text2=text.getText();
		 if(text1.equals(text2))
			{
			System.out.println("Sales overview & summary text is present");
			}
			else
			{
				System.out.println("Sales overview & summary text is not present");	
			}
	 }
	 
	 public void displayRevenuebd()
	 {
     		 if(image.isDisplayed())
			{
			System.out.println("Revenue Breakdown displayed");
			}
			else
			{
				System.out.println("Revenue Breakdown not displayed");	
			}
	 }
	  
		
		  public void displayFlight() 
		  { 
			  if(driver.getPageSource().contains("Flight")) 
			  {
		  System.out.println("Flight module is displayed"); 
		  } 
			  else 
			  {
		  System.out.println("Flight module is not displayed"); 
		  } 
			  }
		  
		  public void displayVisa() 
		  { 
			  if(driver.getPageSource().contains("Visa")) 
			  {
		  System.out.println("Visa module is displayed"); 
		  } 
			  else 
			  {
		  System.out.println("Visa module is not displayed"); 
		  } 
			  }
		  
		  public void displayTours() 
		  { 
			  if(driver.getPageSource().contains("Tours")) 
			  {
		  System.out.println("Tours module is displayed"); 
		  }
			  else 
			  {
		  System.out.println("Tours module is not displayed"); 
		  } 
			  tours.click();
		  tours1.click(); 
		  managetours.click(); 
		  }
		  
		  public void clickBookings() 
		  {
		  if(driver.getPageSource().contains("Bookings")) 
		  {
		  System.out.println("Bookings module is displayed"); 
		  } else 
		  {
		  System.out.println("Bookings module is not displayed"); 
		  } 
		  bookings.click();
		  }
		 

	public void clickPending() throws InterruptedException 
	{
		
		pending.click();
		Thread.sleep(2000);
		pendingdropdown.click();
		confirmed.click();
	}
	
	
public void checkCount() 
	  {
		 board.click();
		  String numConfirm=numconfirm.getText();
	  String numPending=numpending.getText();
	  System.out.println("Confirmed Bookings :"+numConfirm);
	  System.out.println("Pending Bookings :"+numPending); 
	  }
}
