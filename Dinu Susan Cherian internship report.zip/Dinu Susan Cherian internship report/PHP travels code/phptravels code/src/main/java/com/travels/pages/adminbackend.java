package com.travels.pages;

import org.openqa.selenium.Alert;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.Select;

public class adminbackend {
	WebDriver driver;
	
	@FindBy(xpath="//input[(@type='text')]")
	private WebElement email;
	
	@FindBy(xpath="//input[(@name='password')]")
	private WebElement password;
	
	@FindBy(xpath="//button[(@type='submit')]")
	private WebElement login;
	
	@FindBy(xpath="//button[(@id='dropdownMenuProfile')]")
	private WebElement dropdown;
	
	@FindBy(xpath="/html/body/nav/div/div/div/div[3]/ul/li[5]/a")
	private WebElement logout;
	
	@FindBy(xpath="/html/body/nav/div/div/ul/li[2]/a")
	private WebElement bookings;
	
	@FindBy(xpath="/html/body/div[2]/div[2]/main/div/div[2]/div/div/div[2]/div/table/thead/tr/th[12]")
	private WebElement paymentstatus;
	
	@FindBy(xpath="//option[text()='paid']//following::td[2]//a")
	private WebElement invoice;
	
	@FindBy(xpath="//div[(text()='Cancelled Bookings')]")
	private WebElement cancelled;
	
	@FindBy(xpath="/html/body/div[2]/div[2]/main/div/div[2]/div/div/div[2]/div/table/tbody/tr/td")
	private WebElement nodata;
	
	@FindBy(xpath="//div[(text()='Pending Bookings')]")
	private WebElement pending;
	
	@FindBy(xpath="/html/body/div[2]/div[2]/main/div/div[2]/div/div/div[2]/div/table/thead/tr/th[11]")
	private WebElement bookingstatus;
	
	@FindBy(xpath="/html/body/div[2]/div[2]/main/div/div[2]/div/div/div[2]/div/table/tbody/tr/td[15]/button")
	private WebElement delete;
	
	@FindBy(xpath="/html/body/div[2]/div[2]/main/div/div[2]/div/div/div[2]/div/table/tbody/tr[1]/td[11]/select")
	private WebElement statusdropdown1;
	
	@FindBy(xpath="//a[1][(@href='https://phptravels.net/api/admin')]")
	private WebElement board;
	
	@FindBy(xpath="/html/body/div[2]/div[2]/main/div/div[2]/div[1]/a/div/div/div/div[1]/div[1]")
	private WebElement numconfirm;
	
	@FindBy(xpath="/html/body/div[2]/div[2]/main/div/div[2]/div[2]/a/div/div/div/div[1]/div[1]")
	private WebElement numpending;
	
	@FindBy(xpath="//a[(text()='Website')]")
	private WebElement website;
	
	public adminbackend (WebDriver driver) {
		this.driver = driver;
		PageFactory.initElements(driver, this);
	}
	
	public void setEmail(String emailid) 
	  { 
		email.sendKeys(emailid); 
		  }
	
	public void setpassword(String pswd) 
	  { 
		password.sendKeys(pswd); 
		  }
	
	 public void clickLogin() 
	  { 
		 login.click();
		 }
	 
	 public void clickDropdown() 
	  { 
		 dropdown.click();
		 }
	 
	 public void clickLogout() 
	  { 
		 logout.click();
		 }
	 
	 public void clickBookings() 
	  { 
		 bookings.click();
		 }
	 
	 public void clickInvoice()
	 {
		paymentstatus.click();
		 invoice.click();
	}
	 
	 
	 public void clickDelete() throws InterruptedException
	 {
		 cancelled.click();
		 Thread.sleep(2000);
		 String value=nodata.getText();
		 String value1="No data available in table";
		 if(value.equals(value1))
		 {
			 System.out.println("No Cancelled Bookings");
		 }
		 else
		 {
			 delete.click(); 
			 Alert al=driver.switchTo().alert();
			 al.accept();
		 }
	 }
	 
	 public void clickPending() throws InterruptedException
	 {
		pending.click();
		 }
	 
	 public void clickPendingdropdown() throws InterruptedException
		{

			Select pendingdd=new Select(statusdropdown1);
			pendingdd.selectByIndex(1);
		 		}
	 
	 public void checkCount() throws InterruptedException 
	  {
		 board.click();
		 Thread.sleep(2000);
		  String numConfirm=numconfirm.getText();
	  String numPending=numpending.getText();
	  System.out.println("Confirmed Bookings :"+numConfirm);
	  System.out.println("Pending Bookings :"+numPending); 
	  }

	public void clickWebsite()
	 {
		 website.click();
	}
}
