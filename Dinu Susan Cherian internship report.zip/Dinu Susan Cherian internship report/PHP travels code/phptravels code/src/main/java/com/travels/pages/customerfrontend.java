package com.travels.pages;

import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class customerfrontend {
	WebDriver driver;
	
	@FindBy (xpath="//input[(@name='email')]")
	  private WebElement email;
	
	@FindBy (xpath="//input[(@name='password')]")
	  private WebElement password;
	
	@FindBy(xpath="//button[(@type='submit')]")
	private WebElement login;
	
	@FindBy(xpath="/html/body/div[4]/div/div[3]/ul/li[2]/a")
	private WebElement bookings;
	
	@FindBy(xpath="/html/body/div[4]/div/div[3]/ul/li[3]/a")
	private WebElement addfunds;
	
	@FindBy(xpath="/html/body/div[4]/div/div[3]/ul/li[4]/a")
	private WebElement profile;
	
	@FindBy(xpath="/html/body/div[4]/div/div[3]/ul/li[5]/a")
	private WebElement logout;
	
	@FindBy(xpath="//input[(@id='gateway_paypal')]")
	private WebElement paypal;
	
	@FindBy(xpath="//button[(text()='Pay Now ')]")
	private WebElement pay;
	
	@FindBy(xpath="//button[@id='currency']")
	private WebElement account;
	
	@FindBy(xpath="//a[text()=' My Bookings']")
	private WebElement mybookings;
	
	@FindBy(xpath="/html/body/section[1]/div/div[2]/div/div[1]/div/div/div[2]/div/table/tbody/tr[1]/td[4]/div/a")
	private WebElement voucher;
	
	@FindBy(xpath="//input[(@name='address1')]")
	private WebElement address;
	
	@FindBy(xpath="/html/body/div[6]/div/div/div/button")
	private WebElement gotit;
	
	@FindBy(xpath="/html/body/section[1]/div/div[2]/div/div[1]/div/div/div[2]/form/div[3]/button")
	private WebElement update;
	
	public customerfrontend (WebDriver driver) {
		this.driver = driver;

		PageFactory.initElements(driver, this);
	}
	 
	public void setEmail(String emailid) 
	  { 
		  email.sendKeys(emailid); 
		  }
	 
	public void setPassword(String pswd) 
	  { 
		  password.sendKeys(pswd); 
		  }
	
	public void clickLogin() 
	  { 
		  login.click();
		 
		  }
	 
	public void clickBookings() 
	  { 
		  bookings.click();
		 
		  }
	 
	 public void clickAddfunds() 
	  { 
		  addfunds.click();
		  }
	 
	 public void clickMyprofile() 
	  { 
		  profile.click();
		  ((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView();", update);
		  }
	 
	 public void clickLogout() 
	  { 
		  logout.click();
		  }
	 
	 public void clickpaypal() 
	  { 
		  paypal.click();
		  }
	
	 public void clickpay() 
	  { 
		  pay.click();
		  }
	 
	 public void clickAccount() 
	  { 
		  account.click();
		  }
	 
	 public void clickMybookings() 
	  { 
		  mybookings.click();
		  }
	 
	 
	 public void clickvoucher() 
	  { 
		 voucher.click();
		  }
	 
	 public void setAddress(String address1) 
	  { 
		 address.clear();
		  address.sendKeys(address1); 
		  }
	 
	 public void clickGotit() 
	  { 
		 gotit.click();
		  }
	 
	 public void clickUpdate() 
	  {
		 JavascriptExecutor js = (JavascriptExecutor)driver;
		 js.executeScript("arguments[0].click();", update);
		 
		  }
}
