package com.travels.pages;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class agentfrontend {
	WebDriver driver;
	
	@FindBy (xpath="//input[(@name='email')]")
	  private WebElement email;
	
	@FindBy (xpath="//input[(@name='password')]")
	  private WebElement password;
	
	@FindBy(xpath="//button[(@type='submit')]")
	private WebElement login;
	
	@FindBy(xpath="/html/body/div[4]/div/div[3]/ul/li[2]/a")
	private WebElement bookings;
	
	@FindBy(xpath="/html/body/div[4]/div/div[3]/ul/li[3]/a")
	private WebElement addfunds;
	
	@FindBy(xpath="/html/body/div[4]/div/div[3]/ul/li[4]/a")
	private WebElement profile;
	
	@FindBy(xpath="/html/body/div[4]/div/div[3]/ul/li[5]/a")
	private WebElement logout;
	
	@FindBy(xpath="/html/body/header/div/div/div/div/div/div[1]/a/img")
	private WebElement home;
	
	@FindBy(xpath="//a[(text()='Hotels')]")
	private WebElement hotels;
	
	@FindBy(xpath="//a[(text()='flights')]")
	private WebElement flights;
	
	@FindBy(xpath="//a[text()='Tours']")
	private WebElement tours;
	
	@FindBy(xpath="//a[(text()='visa')]")
	private WebElement visa;
	
	@FindBy(xpath="//a[text()='Blog']")
	private WebElement blog;
	
	@FindBy(xpath="//a[text()='Offers']")
	private WebElement offers;
	
	@FindBy(xpath="//span[(@class='select2-selection select2-selection--single')]")
	private WebElement search;
	
	@FindBy(xpath="//input[(@type='search')]")
	private WebElement cityname;
	
	@FindBy(xpath="//li[(@class='select2-results__option select2-results__option--highlighted')]")
	private WebElement city;
	
	@FindBy(xpath="//span[(@class='ladda-label')]")
	private WebElement search1;
	
	@FindBy(xpath="/html/body/section[2]/div/div/div[2]/section/ul/li[1]/div/div[1]/a")
	private WebElement details;
	
	@FindBy(xpath="//button[(@id='currency')]")
	private WebElement currency;
	
	@FindBy(xpath="//a[(text()=' INR')]")
	private WebElement inr;
	
	public agentfrontend (WebDriver driver) {
		this.driver = driver;

		PageFactory.initElements(driver, this);
	}
	
	public void setEmail(String emailid) 
	  { 
		  email.sendKeys(emailid); 
		  }
	 public void setpassword(String pswd) 
	  { 
		  password.sendKeys(pswd); 
		  }
	 public void clickLogin() 
	  { 
		  login.click();
		 
		  }
	 public void clickBookings() 
	  { 
		  bookings.click();
		 
		  }
	 
	 public void clickAddfunds() 
	  { 
		  addfunds.click();
		  }
	 public void clickMyprofile() 
	  { 
		  profile.click();
		  }
	 public void clickLogout() 
	  { 
		  logout.click();
		  }
	 
	 public void clicklogo()
	 {
		 home.click();
	 }
	 
	 public void clickHotels()
	 {
		 hotels.click();
	 }
	 
	 public void clickFlights()
	 {
		 flights.click();
	 }
	 
	 public void clickTours()
	 {
		 tours.click();
	 }
	 
	 public void clickVisa()
	 {
		 visa.click();
	 }
	 
	 public void clickBlog()
	 {
		 blog.click();
	 }
	 
	 public void clickOffers()
	 {
		 offers.click();
	 }
	 
	 public void searchHotel()
	 { 
		 search.click();
	 }
	 
	 public void typeCity()
	 {
		cityname.sendKeys("Dubai");
	 }
	 
	 public void clickCity()
	 {
		 city.click();
	 }
	 

	 public void clickSearch()
	 {
		 search1.click();
	 }
	 
	 public void clickDetails()
	 {
		 details.click();
	 }
	 
	 public void clickCurrency()
	 {
		 currency.click();
	 }
	 
	 public void clickInr()
	 {
		 inr.click();
	 }
	 
}
