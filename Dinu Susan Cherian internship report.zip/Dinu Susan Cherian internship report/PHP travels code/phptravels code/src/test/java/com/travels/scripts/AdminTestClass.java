package com.travels.scripts;

import java.io.IOException;

import org.testng.annotations.Test;

import com.travels.pages.adminbackend;
import com.travels.utilities.ExcelUtility;

public class AdminTestClass extends AdminTestBase{
	
		adminbackend ObjAdm;
		
		@Test(priority=1)
		public void verifyLogin1() throws IOException
		{
			ObjAdm=new adminbackend(driver);
			String email=ExcelUtility.getCellData2(1, 0); 
			String password=ExcelUtility.getCellData2(1, 1); 
			ObjAdm.setEmail(email);
			ObjAdm.setpassword(password); 
		    ObjAdm.clickLogin();
		    ObjAdm.clickDropdown();
		    ObjAdm.clickLogout();
		}
		
		@Test(priority=2)
		public void verifyLogin2() throws IOException
		{
			ObjAdm=new adminbackend(driver);
			String email=ExcelUtility.getCellData2(2, 0); 
			String password=ExcelUtility.getCellData2(2, 1); 
			ObjAdm.setEmail(email);
			ObjAdm.setpassword(password); 
		    ObjAdm.clickLogin();
		}
		
		@Test(priority=3)
		public void verifyLogin3() throws IOException
		{
			ObjAdm=new adminbackend(driver);
			driver.navigate().refresh();
			String email=ExcelUtility.getCellData2(3, 0); 
			String password=ExcelUtility.getCellData2(3, 1); 
			ObjAdm.setEmail(email);
			ObjAdm.setpassword(password); 
		    ObjAdm.clickLogin();
		}
		
		@Test(priority=4)
		public void verifyLogin4() throws IOException
		{
			ObjAdm=new adminbackend(driver);
			driver.navigate().refresh();
			String email=ExcelUtility.getCellData2(4, 0); 
			String password=ExcelUtility.getCellData2(4, 1); 
			ObjAdm.setEmail(email);
			ObjAdm.setpassword(password); 
		    ObjAdm.clickLogin();
		}
		
		@Test(priority=5)
		public void verifyLogin5() throws IOException
		{
			ObjAdm=new adminbackend(driver);
			driver.navigate().refresh();
			String email=ExcelUtility.getCellData2(5, 0); 
			String password=ExcelUtility.getCellData2(5, 1); 
			ObjAdm.setEmail(email);
			ObjAdm.setpassword(password); 
		    ObjAdm.clickLogin();
		}
		
		@Test(priority=6)
		public void verifyBookings() throws IOException, InterruptedException
		{
			ObjAdm=new adminbackend(driver);
			driver.navigate().refresh();
			String email=ExcelUtility.getCellData2(1, 0); 
			String password=ExcelUtility.getCellData2(1, 1); 
			ObjAdm.setEmail(email);
			ObjAdm.setpassword(password); 
		    ObjAdm.clickLogin();
			ObjAdm.clickBookings();
			String mainWindow=driver.getWindowHandle();
			ObjAdm.clickInvoice();
			Thread.sleep(8000);
			driver.switchTo().window(mainWindow);
			}
		
		@Test(priority=7)
		public void verifyCancel() throws InterruptedException
		{
			ObjAdm.clickDelete();
			Thread.sleep(2000);
		}
		
		@Test(priority=8)
		public void verifyDashboard() throws InterruptedException
		{
			ObjAdm.clickPending();
			ObjAdm.clickPendingdropdown();
			Thread.sleep(2000);
			ObjAdm.checkCount();
		}
		
		@Test(priority=9)
		public void verifyLink()
		{
			ObjAdm.clickWebsite();
		}
}
