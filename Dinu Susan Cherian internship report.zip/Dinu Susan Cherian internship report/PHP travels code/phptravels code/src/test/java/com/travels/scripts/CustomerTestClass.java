package com.travels.scripts;

import java.io.IOException;

import org.testng.annotations.Test;

import com.travels.pages.customerfrontend;
import com.travels.utilities.ExcelUtility;

public class CustomerTestClass extends CustomerTestBase{
	customerfrontend ObjCust;
	
	@Test(priority=1)
	public void verifyLogin1() throws IOException
	{
		ObjCust=new customerfrontend(driver);
		String email=ExcelUtility.getCellData(1, 0); 
		String password=ExcelUtility.getCellData(1, 1); 
		ObjCust.setEmail(email);
		ObjCust.setPassword(password); 
	    ObjCust.clickLogin();
	    ObjCust.clickLogout();
	}
	
	@Test(priority=2)
	public void verifyLogin2() throws IOException
	{
		ObjCust=new customerfrontend(driver);
		driver.navigate().refresh();
		String email=ExcelUtility.getCellData(2, 0); 
		String password=ExcelUtility.getCellData(2, 1); 
		ObjCust.setEmail(email);
		ObjCust.setPassword(password); 
	    ObjCust.clickLogin();
	}
	
	@Test(priority=3)
	public void verifyLogin3() throws IOException
	{
		ObjCust=new customerfrontend(driver);
		driver.navigate().refresh();
		String email=ExcelUtility.getCellData(3, 0); 
		String password=ExcelUtility.getCellData(3, 1); 
		ObjCust.setEmail(email);
		ObjCust.setPassword(password); 
	    ObjCust.clickLogin();
	}
	
	@Test(priority=4)
	public void verifyLogin4() throws IOException
	{
		ObjCust=new customerfrontend(driver);
		driver.navigate().refresh();
		String email=ExcelUtility.getCellData(4, 0); 
		String password=ExcelUtility.getCellData(4, 1); 
		ObjCust.setEmail(email);
		ObjCust.setPassword(password); 
	    ObjCust.clickLogin();
	}
	
	@Test(priority=5)
	public void verifyLogin5() throws IOException
	{
		ObjCust=new customerfrontend(driver);
		driver.navigate().refresh();
		String email=ExcelUtility.getCellData(5, 0); 
		String password=ExcelUtility.getCellData(5, 1); 
		ObjCust.setEmail(email);
		ObjCust.setPassword(password); 
	    ObjCust.clickLogin();
	}
	
	@Test(priority=6)
	public void verifyLink() throws IOException
	{
		ObjCust=new customerfrontend(driver);
		driver.navigate().refresh();
		String email=ExcelUtility.getCellData(1, 0); 
		String password=ExcelUtility.getCellData(1, 1); 
		ObjCust.setEmail(email);
		ObjCust.setPassword(password); 
	    ObjCust.clickLogin();
	    ObjCust.clickBookings();
	    ObjCust.clickAddfunds();
	    ObjCust.clickMyprofile();
	    ObjCust.clickLogout();
	  }
	
	@Test(priority=7)
    public void verifyPayment() throws IOException, InterruptedException 
	{
		ObjCust=new customerfrontend(driver);
		driver.navigate().refresh();
		String email=ExcelUtility.getCellData(1, 0); 
		String password=ExcelUtility.getCellData(1, 1); 
		ObjCust.setEmail(email);
		ObjCust.setPassword(password); 
	    ObjCust.clickLogin();
	    Thread.sleep(2000);
		ObjCust.clickGotit();
	    ObjCust.clickAddfunds();
	    ObjCust.clickpaypal();
	    ObjCust.clickpay();
	   	}
	
	
	@Test(priority=8)
	public void verifyBookings() throws InterruptedException 
	{
		
		ObjCust.clickAccount();
		ObjCust.clickMybookings();
		Thread.sleep(2000);
		String mainWindow=driver.getWindowHandle();
		ObjCust.clickvoucher();
		Thread.sleep(8000);
		driver.switchTo().window(mainWindow);
	}
	
	@Test(priority=9)
	public void verifyUpdation() throws InterruptedException, IOException
	{
		ObjCust.clickMyprofile();
		Thread.sleep(2000);
		String address=ExcelUtility.getCellData0(34, 7); 
		ObjCust.setAddress(address);
		ObjCust.clickUpdate();
	}
}
