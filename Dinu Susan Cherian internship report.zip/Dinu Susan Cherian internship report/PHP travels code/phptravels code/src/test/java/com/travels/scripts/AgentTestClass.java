package com.travels.scripts;

import java.io.IOException;

import org.testng.annotations.Test;

import com.travels.pages.agentfrontend;
import com.travels.utilities.ExcelUtility;

public class AgentTestClass extends AgentTestBase{
agentfrontend Objage;

@Test(priority=1)
public void verifyLogin1() throws IOException
{
	Objage=new agentfrontend(driver);
	String email=ExcelUtility.getCellData1(1, 0); 
	String password=ExcelUtility.getCellData1(1, 1); 
	Objage.setEmail(email);
	Objage.setpassword(password); 
    Objage.clickLogin();
    Objage.clickLogout();
    }

@Test(priority=2)
public void verifyLogin2() throws IOException
{
	Objage=new agentfrontend(driver);
	driver.navigate().refresh();
	String email=ExcelUtility.getCellData1(2, 0); 
	String password=ExcelUtility.getCellData1(2, 1); 
	Objage.setEmail(email);
	Objage.setpassword(password); 
    Objage.clickLogin();
}

@Test(priority=3)
public void verifyLogin3() throws IOException
{
	Objage=new agentfrontend(driver);
	driver.navigate().refresh();
	String email=ExcelUtility.getCellData1(3, 0); 
	String password=ExcelUtility.getCellData1(3, 1); 
	Objage.setEmail(email);
	Objage.setpassword(password); 
    Objage.clickLogin();
}

@Test(priority=4)
public void verifyLogin4() throws IOException
{
	Objage=new agentfrontend(driver);
	driver.navigate().refresh();
	String email=ExcelUtility.getCellData1(4, 0); 
	String password=ExcelUtility.getCellData1(4, 1); 
	Objage.setEmail(email);
	Objage.setpassword(password); 
    Objage.clickLogin();
}

@Test(priority=5)
public void verifyLogin5() throws IOException
{
	Objage=new agentfrontend(driver);
	driver.navigate().refresh();
	String email=ExcelUtility.getCellData1(5, 0); 
	String password=ExcelUtility.getCellData1(5, 1); 
	Objage.setEmail(email);
	Objage.setpassword(password); 
    Objage.clickLogin();
}



@Test(priority=6)
public void verifyLink() throws IOException
{
	Objage=new agentfrontend(driver);
	String email=ExcelUtility.getCellData1(1, 0); 
	String password=ExcelUtility.getCellData1(1, 1); 
	Objage.setEmail(email);
	Objage.setpassword(password); 
    Objage.clickLogin();
	Objage.clickBookings();
    Objage.clickAddfunds();
    Objage.clickMyprofile();
    Objage.clickLogout();
}

@Test(priority=7)
public void verifyLink1() throws IOException, InterruptedException
{
	Objage=new agentfrontend(driver);
	String email=ExcelUtility.getCellData1(1, 0); 
	String password=ExcelUtility.getCellData1(1, 1); 
	Objage.setEmail(email);
	Objage.setpassword(password); 
    Objage.clickLogin();
    Objage.clicklogo();
    Thread.sleep(2000);
    Objage.clickHotels();
    Thread.sleep(2000);
    Objage.clickFlights();
    Thread.sleep(2000);
    Objage.clickTours();
    Thread.sleep(2000);
    Objage.clickVisa();
    Thread.sleep(2000);
    Objage.clickBlog();
    Thread.sleep(2000);
    Objage.clickOffers();
    Thread.sleep(2000);
}

@Test(priority=8)
public void verifySearch() throws InterruptedException 
{
	 Objage.clickHotels();
	 Objage.searchHotel();
	 Objage.typeCity();
	 Thread.sleep(2000);
	 Objage.clickCity();
	 Objage.clickSearch();
	 Objage.clickDetails();
	 Thread.sleep(2000);
}

@Test(priority=9)
public void verifyCurrency() 
{
	Objage.clickCurrency();
	Objage.clickInr();
}
}
