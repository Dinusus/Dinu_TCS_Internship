package com.travels.scripts;

import java.io.IOException;

import org.testng.annotations.Test;

import com.travels.pages.supplierbackend;
import com.travels.utilities.ExcelUtility;

public class SupplierTestClass extends SupplierTestBase {
	supplierbackend ObjSup;
	
	@Test(priority=1)
	public void verifyLogin1() throws IOException 
	{
		ObjSup=new supplierbackend(driver);
		String email=ExcelUtility.getCellData3(1, 0); 
		String password=ExcelUtility.getCellData3(1, 1);
		ObjSup.setEmail(email);
		ObjSup.setpassword(password); 
	    ObjSup.clickLogin();
	    ObjSup.clickDropdown();
	    ObjSup.clickLogout();
	    
	}
	
	@Test(priority=2)
	public void verifyLogin2() throws IOException, InterruptedException 
	{
		ObjSup=new supplierbackend(driver);
		String email=ExcelUtility.getCellData3(2, 0); 
		String password=ExcelUtility.getCellData3(2, 1);
		ObjSup.setEmail(email);
		ObjSup.setpassword(password); 
	    ObjSup.clickLogin();
	    Thread.sleep(2000);
	    
	}
	
	@Test(priority=3)
	public void verifyLogin3() throws IOException, InterruptedException 
	{
		ObjSup=new supplierbackend(driver);
		driver.navigate().refresh();
		String email=ExcelUtility.getCellData3(3, 0); 
		String password=ExcelUtility.getCellData3(3, 1);
		ObjSup.setEmail(email);
		ObjSup.setpassword(password); 
	    ObjSup.clickLogin();
	    Thread.sleep(2000);
	   }
	
	@Test(priority=4)
	public void verifyLogin4() throws IOException, InterruptedException 
	{
		ObjSup=new supplierbackend(driver);
		driver.navigate().refresh();
		String email=ExcelUtility.getCellData3(4, 0); 
		String password=ExcelUtility.getCellData3(4, 1);
		ObjSup.setEmail(email);
		ObjSup.setpassword(password); 
	    ObjSup.clickLogin();
	    Thread.sleep(2000);
	}
	
	@Test(priority=5)
	public void verifyLogin5() throws IOException, InterruptedException 
	{
		ObjSup=new supplierbackend(driver);
		driver.navigate().refresh();
		String email=ExcelUtility.getCellData3(5, 0); 
		String password=ExcelUtility.getCellData3(5, 1);
		ObjSup.setEmail(email);
		ObjSup.setpassword(password); 
	    ObjSup.clickLogin();
	    Thread.sleep(2000);
	 }
	
	@Test(priority=6)
	public void verifyText() throws IOException
	{
		ObjSup=new supplierbackend(driver);
		String email=ExcelUtility.getCellData3(1, 0); 
		String password=ExcelUtility.getCellData3(1, 1);
		ObjSup.setEmail(email);
		ObjSup.setpassword(password); 
	    ObjSup.clickLogin();
		ObjSup.selectText();
	}
	
	@Test(priority=7)
	public void verifyDisplay()
	{
		ObjSup.displayRevenuebd();
	}

	
	  @Test(priority=8)
	  public void verifyBooking() throws InterruptedException
	  { 
		  
		  ObjSup.clickPending();
		Thread.sleep(2000);
		  ObjSup.checkCount();
	  }
	 
		
		@Test(priority=9) 
		  public void verifyModules() throws InterruptedException
		  { 
			ObjSup.displayFlight();
			ObjSup.displayVisa(); 
			ObjSup.displayTours(); 
			ObjSup.clickBookings();
			ObjSup.clickPending();
		  }
		 
		 

	
}
